# drone.io autoscroll

- Chrome extension

Allow to scroll bottom build progress on CI drone.io

Install:

https://chrome.google.com/webstore/detail/droneio-autoscroll/kelkfcnlolmkefdoodjceklekhhjlhnc

![Example video](https://raw.githubusercontent.com/misak113/drone.io-autoscroll/master/video/example.gif)
