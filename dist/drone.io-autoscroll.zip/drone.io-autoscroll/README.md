# drone.io autoscroll

- Chrome extension

Allow to scroll bottom build progress on CI drone.io

![Example video](https://raw.githubusercontent.com/misak113/drone.io-autoscroll/master/video/example.gif)
